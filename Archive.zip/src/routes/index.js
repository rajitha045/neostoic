import user from './user';
import jobPostings from './jobPostings';

export default {
  user,
  jobPostings,
};
